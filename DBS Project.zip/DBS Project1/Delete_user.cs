﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DBS_Project1
{
    public partial class Delete_user : Form
    {
        string selection = "";
        public Delete_user()
        {
            InitializeComponent();
            fills1();
            fills2();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selection = "st";
                // When a cell is clicked in the DataGridView, populate TextBoxes with the selected row's data
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Username"].Value.ToString(); // Replace "Course_Name" with the actual column name
                textBox2.Text = row.Cells["Department"].Value.ToString(); // Replace "Description" with the actual column name
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selection = "tech";
                // When a cell is clicked in the DataGridView, populate TextBoxes with the selected row's data
                DataGridViewRow row = dataGridView2.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Username"].Value.ToString(); // Replace "Course_Name" with the actual column name
                textBox2.Text = row.Cells["Department"].Value.ToString(); // Replace "Description" with the actual column name
            }
        }

        private void fills1()
        {
            string query = "";
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            query = "SELECT s_username AS Username,s_f_name AS First_Name,s_l_name AS Surname,s_age AS Age,s_email AS Email,s_pass AS Password,s_dept AS Department FROM students;";
            SqlCommand cmd = new SqlCommand(query, connection);
            DataSet DS = new DataSet();
            SqlDataAdapter DA = new SqlDataAdapter(cmd);
            DA.Fill(DS, "teachers");
            dataGridView1.DataSource = DS.Tables["teachers"];
            connection.Close();
        }

        private void fills2()
        {
            string query = "";
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            query = "SELECT teachers.t_username AS Username,teachers.t_f_name AS First_Name,teachers.t_l_name AS Surname,teachers.t_age AS Age,teachers.t_email AS Email,teachers.t_pass AS Password,teachers.t_dept AS Department FROM teachers;";
            SqlCommand cmd = new SqlCommand(query, connection);
            DataSet DS = new DataSet();
            SqlDataAdapter DA = new SqlDataAdapter(cmd);
            DA.Fill(DS, "teachers");
            dataGridView2.DataSource = DS.Tables["teachers"];
            connection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Delete the selected row from the database

            {

                string query = "";
                string b1 = textBox1.Text;
                string b2 = textBox2.Text;

                string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";

                //connection string
                if (selection == "st")
                {
                    query = " DELETE FROM students WHERE s_username = '" + textBox1.Text + "';";
                }
                else if (selection == "tech")
                {
                    query = " DELETE FROM students WHERE s_username = '" + textBox1.Text + "';";
                }
                SqlConnection dbConnection = new SqlConnection(connectionString);
                dbConnection.Open();
                SqlCommand command = new SqlCommand(query, dbConnection);
                command.ExecuteNonQuery();
                MessageBox.Show("Data Deleted Successfully");
                fills1();
                fills2();
                dbConnection.Close();
            }



        }

        private void button1_Click(object sender, EventArgs e)
        {
            manage_users MU = new manage_users();
            MU.Show();
            this.Hide();
        }
    }
    
}

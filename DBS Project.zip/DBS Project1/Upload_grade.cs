﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace DBS_Project1
{
    public partial class Upload_grade : Form
    {
        public Upload_grade()
        {

            InitializeComponent();
            populate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //fill the student name textboxes with the data from the gridview
            studentNameTXTbox.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();


        }
        private void populate()
        {
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            // Create a new DataTable to hold the data from the database
            DataTable dt = new DataTable();
            // Establish a connection to the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL query to select all data from your table
                string query = "SELECT students.s_username AS Username,students.s_f_name AS First_Name,students.s_l_name AS Surname,students.s_age AS Age,students.s_email AS Email,students.s_pass AS Password,students.s_dept From students INNER JOIN enrollment ON students.s_username = enrollment.st_username INNER JOIN Course ON enrollment.course_id=Course.CourseID INNER JOIN teachers ON t_dept=s_dept;";
                // Create a SqlDataAdapter to fet
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                // Fill the DataTable with the data from the database
                adapter.Fill(dt);
            }
            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //update the grade of the student
            //error if text box are empty
            if(studentNameTXTbox.Text=="" || gradeTXTBOX.Text=="" || courseIDTXT.Text == "")
            {
                MessageBox.Show("Please Fill All the Fields");
                return;
            }
            
            
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            try {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string name = studentNameTXTbox.Text.ToString();
                    string grade = gradeTXTBOX.Text.ToString();
                    string courseid = courseIDtxtbox.Text.ToString();
                    int courseID = Int32.Parse(courseid);
                    string query = "INSERT INTO grade (st_username,course_id,grade) VALUES ('" + name + "','" + courseID + "','" + grade + "');";
                    SqlCommand command = new SqlCommand(query, connection);


                    command.ExecuteNonQuery();
                    connection.Close();
                    MessageBox.Show("Grade Updated Successfully");
                    populate(); } }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
            }
        }
    }


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBS_Project1
{
    public partial class modify_course : Form
    {
        public modify_course()
        {
            InitializeComponent();
            LoadData();
        }
        string a1 = "";
        string a2 = "";
        string a3 = "";
        string a4 = "";
        string b1 = "";
        string b2 = "";
        string b3 = "";
        string b4 = "";
        string connectionString = "";

        private void button1_Click(object sender, EventArgs e)
        {
            offer o = new offer();
            o.Show();
            this.Hide();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Course_Name"].Value.ToString(); 
                textBox2.Text = row.Cells["Description"].Value.ToString(); 
                textBox3.Text = row.Cells["Credit_Hours"].Value.ToString();
                textBox4.Text = row.Cells["Department"].Value.ToString();
                a1 = row.Cells["Course_Name"].Value.ToString();
                a2 = row.Cells["Description"].Value.ToString();
                a3 = row.Cells["Credit_Hours"].Value.ToString();
                a4 = row.Cells["Department"].Value.ToString();
            }
        }
        private void LoadData()
        {
            connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            // Create a new DataTable to hold the data from the database
            DataTable dt = new DataTable();
            // Establish a connection to  database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL query to select all data from your table
                string query = "SELECT Name AS Course_Name,Description,Credits AS Credit_Hours,Dept_name AS Department FROM Course;";
                // Create a SqlDataAdapter to fetch the data
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                // Fill the DataTable with thedata from the database
                adapter.Fill(dt);
            }
            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Update data in the database
            b1=textBox1.Text;
            b2=textBox2.Text;
            b3=textBox3.Text;
            b4=textBox4.Text;

            //connect to database
            SqlConnection dbConnection=new SqlConnection(connectionString);
            dbConnection.Open();
            string query = "UPDATE Course SET Name='" + b1 + "',Description='" + b2 + "',Credits='" + b3 + "',Dept_name='" + b4 + "' WHERE Name='" + a1 + "'";
            SqlCommand command = new SqlCommand(query, dbConnection);
            command.ExecuteNonQuery();
            MessageBox.Show("Data Updated Successfully");
            LoadData();
            dbConnection.Close();

        }
        private void UpdateDatabase()
        {
           
                    
                       
                            
                          
                            
                        

                    }
            }
    }

    


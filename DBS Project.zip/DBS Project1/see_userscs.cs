﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBS_Project1
{
    public partial class see_userscs : Form
    {
        string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
        public see_userscs()
        {
            InitializeComponent();
            LoadData1();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void LoadData1()
        {
            // Create a new DataTable to hold the data from the database
            DataTable dt = new DataTable();
            // Establish a connection to the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL query to select all data from your table
                string query = "SELECT Name AS Course_Name, Description, Credits AS Credit_Hours, Dept_name AS Department FROM Course;";
                // Create a SqlDataAdapter to fetch the data
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                // Fill the DataTable with the data from the database
                adapter.Fill(dt);
            }
            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = dt;
        }
    }
}

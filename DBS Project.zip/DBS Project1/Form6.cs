﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DBS_Project1
{
    public partial class Form6 : Form
    {

        string ID = "";
        string date = "";

        public Form6()
        {
            
            InitializeComponent();
            fills1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Delete the selected row from the database

            {
                if(courseIDTXT.Text=="")
                {
                    MessageBox.Show("Please select a course to enroll");
                    return;
                }

                int courseID=Int32.Parse(courseIDTXT.Text);
                string date=DateTime.Now.ToString("yyyy-MM-dd");

                try
                {
                    string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
                    //connection string
                    SqlConnection dbConnection = new SqlConnection(connectionString);
                    string query = "INSERT INTO enrollment (st_username,course_id,enroll_date) VALUES ('" + student_info.loggedinstudentusername + "','" + courseID + "','" + date + "');";
                    dbConnection.Open();
                    SqlCommand command = new SqlCommand(query, dbConnection);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Enrolled Successfully");
                    fills1();
                    dbConnection.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // When a cell is clicked in the DataGridView, populate TextBoxes with the selected row's data
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                courseIDTXT.Text = row.Cells["CourseID"].Value.ToString(); // Replace "Course_Name" with the actual column name
                 // Replace "Description" with the actual column name
                 //
            }
        }

        private void fills1()
        {
            //fill the datagridview with the data from the database
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            // Create a new DataTable to hold the data from the database
            DataTable dt = new DataTable();
            // Establish a connection to the database
            try
            {
              //select all from course
              using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // SQL query to select all data from your table
                    string query = "SELECT * FROM Course";
                    // Create a SqlDataAdapter to fetch the data
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    // Fill the DataTable with the data from the database
                    adapter.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                // Bind the DataTable to the DataGridView
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}

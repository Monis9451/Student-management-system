﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DBS_Project1
{
    public partial class Seee_grade : Form
    {
        
        public Seee_grade()
        {
            InitializeComponent();
            fills1();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void fills1()
        {
            string query = "";
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            query = "SELECT st_username AS Username,course_id,grade FROM grade WHERE st_username='"+student_info.loggedinstudentusername+"';";
            SqlCommand cmd = new SqlCommand(query, connection);
            DataSet DS = new DataSet();
            SqlDataAdapter DA = new SqlDataAdapter(cmd);
            DA.Fill(DS, "teachers");
            dataGridView1.DataSource = DS.Tables["teachers"];
            connection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
            this.Hide();
        }
    }
}

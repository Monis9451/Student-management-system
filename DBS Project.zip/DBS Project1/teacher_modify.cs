﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBS_Project1
{
    public partial class teacher_modify : Form
    {
        public teacher_modify()
        {
            InitializeComponent();
            show_data();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form5 f5 = new Form5();
            f5.Show();
            this.Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form5 f5 = new Form5();
            f5.Show();
            this.Close();
        }

        private void show_data()
        {
            string query1 = "";
            string username = teacherinfo.loggedinteacherusename;

            // Establish connection to the database
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Create SQL query to retrieve user information from the first table
                query1 = "SELECT * FROM teachers WHERE t_username = '" + username + "'";
                SqlCommand command1 = new SqlCommand(query1, connection);
                SqlDataReader reader1 = command1.ExecuteReader();

                if (reader1.Read())
                {
                    textBox1.Text = reader1["t_f_name"].ToString();
                    textBox2.Text = reader1["t_l_name"].ToString();
                    textBox4.Text = reader1["t_age"].ToString();
                    textBox3.Text = reader1["t_email"].ToString();
                    textBox6.Text = reader1["t_pass"].ToString();
                    textBox5.Text = reader1["t_username"].ToString();
                    textBox7.Text = reader1["t_dept"].ToString();
                }
                reader1.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Get the updated information from your interface
            string newFN = textBox1.Text;
            string newLN = textBox2.Text;
            string newA = textBox4.Text;
            string newE = textBox3.Text;
            string newP = textBox6.Text;
            string newU = textBox5.Text;
            string newD = textBox7.Text;
            string username = teacherinfo.loggedinteacherusename;

            // Establish connection to the database
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Construct SQL query to update data in the database
                string query = "UPDATE teachers SET t_f_name = '" + newFN + "', t_l_name = '" + newLN + "', t_age = '" + newA + "', t_email = '" + newE + "', t_pass = '" + newP + "', t_username = '" + newU + "', t_dept = '" + newD + "' WHERE t_username = '" + username + "'";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@NewFirstName", newFN);
                command.Parameters.AddWithValue("@NewLastName", newLN);
                command.Parameters.AddWithValue("@NewAge", newA);
                command.Parameters.AddWithValue("@NewEmail", newE);
                command.Parameters.AddWithValue("@NewPassword", newP);
                command.Parameters.AddWithValue("@NewUsername", newU);
                command.Parameters.AddWithValue("@NewDepartment", newD);
                command.Parameters.AddWithValue("@Username", username);

                // Execute the query
                int rowsAffected = command.ExecuteNonQuery();

                // Check if the update was successful
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Information Modified successfully!");
                }
                else
                {
                    MessageBox.Show("Failed to Modified information.");
                }
            }
        }
    }
}

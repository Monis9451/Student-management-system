﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBS_Project1
{
    public partial class Form2 : Form
    {
        public static Form2 instance2;
        public Form2()
        {
            InitializeComponent();
            instance2 = this;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            using (GraphicsPath path = new GraphicsPath())
            {
                int radius = 20; // Adjust the radius as needed

                // Define a rectangle with rounded corners
                Rectangle rect = new Rectangle(0, 0, panel1.Width - 1, panel1.Height - 1); // Subtract 1 to prevent clipping of border
                path.AddArc(rect.X, rect.Y, radius * 2, radius * 2, 180, 90);
                path.AddArc(rect.X + rect.Width - radius * 2, rect.Y, radius * 2, radius * 2, 270, 90);
                path.AddArc(rect.X + rect.Width - radius * 2, rect.Y + rect.Height - radius * 2, radius * 2, radius * 2, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius * 2, radius * 2, radius * 2, 90, 90);
                path.CloseFigure();

                // Set the panel's region to the rounded rectangle path
                panel1.Region = new Region(path);

                // Draw the border
                using (Pen pen = new Pen(Color.SkyBlue, 2)) // Adjust the width as needed
                {
                    e.Graphics.DrawPath(pen, path);
                }
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;
            bool userFound = false;
            string query1 = "";

            // Establish connection to the database
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string usertype = "";

                // Create SQL query to retrieve user information from the first table
                if (comboBox1.SelectedItem.ToString()=="Student")
                {
                    usertype = "Student";
                    query1 = "SELECT * FROM students WHERE s_username = '" + username + "' AND s_pass = '" + password + "'";
                }
                else if(comboBox1.SelectedItem.ToString()=="Teacher")
                {
                    usertype= "Teacher";
                    query1 = "SELECT * FROM teachers WHERE t_username = '" + username + "' AND t_pass = '" + password + "'";
                }
                else if (comboBox1.SelectedItem.ToString() == "Admin")
                {
                    usertype = "Admin";
                    query1 = "SELECT * FROM admins WHERE a_username = '" + username + "' AND a_pass = '" + password + "'";
                }
                SqlCommand command1 = new SqlCommand(query1, connection);

                SqlDataReader reader1 = command1.ExecuteReader();

                if (reader1.Read())
                {
                    MessageBox.Show("Login successfull as a " + usertype + "");
                    if(usertype=="Student")
                    {
                        student_info.loggedinstudentusername = username;
                        Form4 form4 = new Form4();
                        form4.Show();
                        this.Hide();
                    }
                    else if (usertype == "Teacher")
                    {
                        teacherinfo.loggedinteacherusename = username;
                        Form5 form5 = new Form5();
                        form5.Show();
                        this.Hide();
                    }
                    else if(usertype == "Admin")
                    {
                        admin_info.loggedinadminusername=username;
                        Admin_portal ap = new Admin_portal();
                        ap.Show();
                        this.Hide();
                    }
                }
                reader1.Close();
            }
        }
    }
}

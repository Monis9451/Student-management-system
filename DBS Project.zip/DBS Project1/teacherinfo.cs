﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBS_Project1
{
    public static class teacherinfo
    {
       public static string loggedinteacherusename="";
    }
    public static class student_info
    {
        public static string loggedinstudentusername="";
    }
    public static class admin_info
    {
        public static string loggedinadminusername = "";
    }
}

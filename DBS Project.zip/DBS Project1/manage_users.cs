﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBS_Project1
{
    public partial class manage_users : Form
    {
        public manage_users()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Admin_portal AP = new Admin_portal();
            AP.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Add_user AU = new Add_user();
            AU.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Delete_user DU = new Delete_user();
            DU.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Add_fees AF = new Add_fees();
            AF.Show();
            this.Hide();
        }
    }
}

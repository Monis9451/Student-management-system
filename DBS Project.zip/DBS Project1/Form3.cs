﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DBS_Project1
{
    public partial class Form3 : Form
    {
        public static Form3 instance3;
        public Form3()
        {
            InitializeComponent();
            instance3 = this;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Address of SQL server and Database
            string connection_string = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";

            // Establish connection
            using (SqlConnection connection = new SqlConnection(connection_string))
            {
                // Open connection
                connection.Open();

                // Create query
                string query = "";
                string FN = textBox1.Text;
                string LN = textBox2.Text;
                string age = textBox4.Text;
                string email= textBox3.Text;
                string password = textBox6.Text;
                string username = textBox5.Text;
                string dept = textBox7.Text;

                // Check the selected item in the ComboBox
                if (comboBox1.SelectedItem != null)
                {
                    if (comboBox1.SelectedItem.ToString() == "Teacher")
                    {
                        // Insert data into the teacher table
                        query = "INSERT INTO teachers(t_f_name,t_l_name,t_age,t_email,t_pass,t_username,t_dept)VALUES('"+FN+"','"+LN+"',"+age+",'"+email+"','"+password+"','"+username+"','"+dept+"')";
                    }
                    else if (comboBox1.SelectedItem.ToString() == "Student")
                    {
                        // Insert data into the student table
                        query = " INSERT INTO students(s_f_name,s_l_name,s_age,s_email,s_pass,s_username,s_dept)VALUES('"+FN+"','"+LN+"',"+age+",'"+email+"','"+password+"','"+username+"','"+dept+"')";
                    }

                    // Execute query
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }

                // Close connection
                connection.Close();
                MessageBox.Show("Sign up successfully");
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            using (GraphicsPath path = new GraphicsPath())
            {
                int radius = 20; // Adjust the radius as needed

                // Define a rectangle with rounded corners
                Rectangle rect = new Rectangle(0, 0, panel1.Width - 1, panel1.Height - 1); // Subtract 1 to prevent clipping of border
                path.AddArc(rect.X, rect.Y, radius * 2, radius * 2, 180, 90);
                path.AddArc(rect.X + rect.Width - radius * 2, rect.Y, radius * 2, radius * 2, 270, 90);
                path.AddArc(rect.X + rect.Width - radius * 2, rect.Y + rect.Height - radius * 2, radius * 2, radius * 2, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius * 2, radius * 2, radius * 2, 90, 90);
                path.CloseFigure();

                // Set the panel's region to the rounded rectangle path
                panel1.Region = new Region(path);

                // Draw the border
                using (Pen pen = new Pen(Color.SkyBlue, 2)) // Adjust the width as needed
                {
                    e.Graphics.DrawPath(pen, path);
                }
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox4.Text, out _))
            {
                // If not a valid number, clear the TextBox
                textBox4.Text = "";
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

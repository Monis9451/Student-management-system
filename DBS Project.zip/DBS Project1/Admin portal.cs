﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBS_Project1
{
    public partial class Admin_portal : Form
    {
        public Admin_portal()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Admin_info a_info = new Admin_info();
            a_info.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Admin_modify am = new Admin_modify();
            am.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            offer o = new offer();
            o.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            see_users SU = new see_users();
            SU.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            manage_users MU = new manage_users();
            MU.Show();
            this.Hide();
        }
    }
}

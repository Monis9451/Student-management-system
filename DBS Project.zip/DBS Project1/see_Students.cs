﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBS_Project1
{
    public partial class see_Students : Form
    {
        public see_Students()
        {
            InitializeComponent();
            LoadData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void LoadData()
        {
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            // Create a new DataTable to hold the data from the database
            DataTable dt = new DataTable();
            // Establish a connection to the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL query to select all data from your table
                //retrieve department of logged in teacher
                string query1="SELECT t_dept FROM teachers WHERE teachers.t_username= '" + teacherinfo.loggedinteacherusename+"'";
                //store department name of teacher
                string deptname = "";
                // Create a SqlCommand object
                SqlCommand command = new SqlCommand(query1, connection);
                // Open the connection
                connection.Open();
                // Execute the SELECT query
                SqlDataReader reader = command.ExecuteReader();
                // Read the result
                while (reader.Read())
                {
                    deptname = reader["t_dept"].ToString();
                }
                // Close the connection
                connection.Close();
                // SQL query to select all data from your table
                connection.Open();


                string query = "SELECT * FROM students WHERE s_dept='" + deptname +"'" ;
                // Create a SqlDataAdapter to fetch the data
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                // Fill the DataTable with the data from the database
                adapter.Fill(dt);
            }
            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = dt;
        }

        private void see_Students_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();
            this.Close();
        }
    }
}

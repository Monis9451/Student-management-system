﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DBS_Project1
{
    public partial class Admin_modify : Form
    {
        public Admin_modify()
        {
            InitializeComponent();
            show_data();
        }

        private void Admin_modify_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Admin_portal admin_Portal = new Admin_portal();
            admin_Portal.Show();
            this.Hide();
        }
        private void show_data()
        {
            string query1 = "";
            string username = admin_info.loggedinadminusername;

            // Establish connection to the database
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Create SQL query to retrieve user information from the first table
                query1 = "SELECT * FROM admins WHERE a_username = '" + username + "'";
                SqlCommand command1 = new SqlCommand(query1, connection);
                SqlDataReader reader1 = command1.ExecuteReader();

                if (reader1.Read())
                {
                    textBox1.Text = reader1["a_f_name"].ToString();
                    textBox2.Text = reader1["a_l_name"].ToString();
                    textBox4.Text = reader1["a_age"].ToString();
                    textBox3.Text = reader1["a_email"].ToString();
                    textBox6.Text = reader1["a_pass"].ToString();
                    textBox5.Text = reader1["a_username"].ToString();
                }
                reader1.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Get the updated information from your interface
            string newFN = textBox1.Text;
            string newLN = textBox2.Text;
            string newA = textBox4.Text;
            string newE = textBox3.Text;
            string newP = textBox6.Text;
            string newU = textBox5.Text;
           

            // Establish connection to the database
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Construct SQL query to update data in the database
                string query = "UPDATE admins SET a_f_name = '" + newFN + "', a_l_name = '" + newLN + "', a_age = '" + newA + "', a_email = '" + newE + "', a_pass = '" + newP + "', a_username = '" + newU + "' WHERE a_username = '" + admin_info.loggedinadminusername + "'";
                SqlCommand command = new SqlCommand(query, connection);
                

                // Execute the query
                int rowsAffected = command.ExecuteNonQuery();

                // Check if the update was successful
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Information Modified successfully!");
                }
                else
                {
                    MessageBox.Show("Failed to Modified information.");
                }
            }
        }
    }
}

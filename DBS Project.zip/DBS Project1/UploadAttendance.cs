﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace DBS_Project1
{
    public partial class UploadAttendance : Form
    {
        public UploadAttendance()
        {

            InitializeComponent();
            populate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //fill the student name textboxes with the data from the gridview
            attendancestatusTXT.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();


        }

        private void populate()
        {
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            // Create a new DataTable to hold the data from the database
            DataTable dt = new DataTable();
            // Establish a connection to the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL query to select all data from your table
                //show attendance of students query
                //show attendance
                string query = "SELECT students.s_username , attendance.attendance_date , attendance.attendance_status FROM attendance INNER JOIN students ON attendance.student_name=students.s_username";



                // Create a SqlDataAdapter to fet
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                // Fill the DataTable with the data from the database
                adapter.Fill(dt);
            }
            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            //insert the attendance
            if(attendancestatusTXT.Text == "" || attendancestatusTXT.Text == "")
            {
                MessageBox.Show("Please fill all the fields");
                return;
            }
            else
            {
                string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        //insert the attendance
                        string name = studentNameTXT.Text.ToString();
                        string status = attendancestatusTXT.Text.ToString();
                        string date = attendancedate.Text.ToString();
                        //convert date to sql date
                        DateTime dt = Convert.ToDateTime(date);
                        date = dt.ToString("yyyy-MM-dd");



                        string query = "INSERT INTO attendance (student_name,attendance_date,attendance_status) VALUES ('" + name + "','" + date + "','" + status + "')";
                        SqlCommand command = new SqlCommand(query, connection);

                        command.ExecuteNonQuery();
                        connection.Close();
                        populate();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                
            }
            
            }
        }
    }


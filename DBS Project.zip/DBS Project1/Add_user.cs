﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBS_Project1
{
    public partial class Add_user : Form
    {
        public Add_user()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            manage_users MU = new manage_users();
            MU.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Address of SQL server and Database
            string connection_string = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";

            // Establish connection
            using (SqlConnection connection = new SqlConnection(connection_string))
            {
                // Open connection
                connection.Open();

                // Create query
                string query = "";
                string FN = textBox1.Text;
                string LN = textBox2.Text;
                string age = textBox4.Text;
                string email = textBox3.Text;
                string password = textBox6.Text;
                string username = textBox5.Text;
                string dept = textBox7.Text;

                // Check the selected item in the ComboBox
                if (comboBox1.SelectedItem != null)
                {
                    if (comboBox1.SelectedItem.ToString() == "Teacher")
                    {
                        // Insert data into the teacher table
                        query = "INSERT INTO teachers(t_f_name,t_l_name,t_age,t_email,t_pass,t_username,t_dept)VALUES('" + FN + "','" + LN + "'," + age + ",'" + email + "','" + password + "','" + username + "','" + dept + "')";
                    }
                    else if (comboBox1.SelectedItem.ToString() == "Student")
                    {
                        // Insert data into the student table
                        query = " INSERT INTO students(s_f_name,s_l_name,s_age,s_email,s_pass,s_username,s_dept)VALUES('" + FN + "','" + LN + "'," + age + ",'" + email + "','" + password + "','" + username + "','" + dept + "')";
                    }

                    // Execute query
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }

                // Close connection
                connection.Close();
                MessageBox.Show("Add user successfully");
            }
        }
    }
}

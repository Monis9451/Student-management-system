﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace DBS_Project1
{
    public partial class Add_fees : Form
    {
        string connectionString = "";
        public Add_fees()
        {
            InitializeComponent();
            LoadData();
        }

        string a1 = "";
        string a2 = "";
        string a3 = "";
        string a4 = "";
        string a5 = "";
        string a6 = "";
        string b1 = "";
        string b2 = "";
        string b3 = "";
        string b4 = "";
        string b5 = "";
        string b6 = "";

        private void button1_Click(object sender, EventArgs e)
        {
            manage_users MU = new manage_users();
            MU.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Update data in the database
            b1 = textBox1.Text;
            b2 = dateTimePicker1.Value.ToString("yyyy-MM-dd");
            b3 = textBox3.Text;
            b4 = textBox4.Text;
            b5 = textBox5.Text;
            b2 = dateTimePicker2.Value.ToString("yyyy-MM-dd");

            // Convert string to DateTime for date fields
            //DateTime subDate = DateTime.ParseExact(b2, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            //DateTime dueDate = DateTime.ParseExact(b6, "dd/MM/yyyy", CultureInfo.InvariantCulture);

            // Connect to the database
            using (SqlConnection dbConnection = new SqlConnection(connectionString))
            {
                dbConnection.Open();
                string query = "UPDATE fee SET Sub_date='"+b2+ "', Amount='"+b3+ "', f_status='"+b4+ "', f_Description='"+b5+ "', due_date='"+b6+"' WHERE st_username='"+a1+"'";
                SqlCommand command = new SqlCommand(query, dbConnection);
                command.Parameters.AddWithValue("@Username", b1);
                command.Parameters.AddWithValue("@SubDate", b2);
                command.Parameters.AddWithValue("@Amount", b3);
                command.Parameters.AddWithValue("@Status", b4);
                command.Parameters.AddWithValue("@Description", b5);
                command.Parameters.AddWithValue("@DueDate", b6);

                try
                {
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Data Updated Successfully");
                        LoadData();
                    }
                    else
                    {
                        MessageBox.Show("No rows updated.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating data: " + ex.Message);
                }
            }
        }

        private void LoadData()
        {
            connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            // Create a new DataTable to hold the data from the database
            DataTable dt = new DataTable();
            // Establish a connection to  database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL query to select all data from your table
                string query = "SELECT st_username AS Username,Sub_date AS Submition_date,Amount,f_status AS Status,f_description AS Description,due_date as Due_Date FROM fee;";
                // Create a SqlDataAdapter to fetch the data
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                // Fill the DataTable with thedata from the database
                adapter.Fill(dt);
            }
            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Username"].Value.ToString();
                dateTimePicker1.Text = row.Cells["Submition_date"].Value.ToString();
                textBox3.Text = row.Cells["Amount"].Value.ToString();
                textBox4.Text = row.Cells["Status"].Value.ToString();
                textBox5.Text = row.Cells["Description"].Value.ToString();
                dateTimePicker2.Text = row.Cells["Due_Date"].Value.ToString();
                a1 = row.Cells["Username"].Value.ToString();
                a2 = row.Cells["Submition_date"].Value.ToString();
                a3 = row.Cells["Amount"].Value.ToString();
                a4 = row.Cells["Status"].Value.ToString();
                a5 = row.Cells["Description"].Value.ToString();
                a6 = row.Cells["Due_Date"].Value.ToString();
            }
        }
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBS_Project1
{
    public partial class delete_course : Form
    {
        string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";

        public delete_course()
        {
            InitializeComponent();
            LoadData();
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            offer o = new offer();
            o.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // When a cell is clicked in the DataGridView, populate TextBoxes with the selected row's data
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Course_Name"].Value.ToString(); // Replace "Course_Name" with the actual column name
                textBox2.Text = row.Cells["Description"].Value.ToString(); // Replace "Description" with the actual column name
                textBox3.Text = row.Cells["Credit_Hours"].Value.ToString(); // Replace "Credit_Hours" with the actual column name
                textBox4.Text = row.Cells["Department"].Value.ToString(); // Replace "Department" with the actual column name
            }
        }

        private void LoadData()
        {
            // Create a new DataTable to hold the data from the database
            DataTable dt = new DataTable();
            // Establish a connection to the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // SQL query to select all data from your table
                string query = "SELECT Name AS Course_Name, Description, Credits AS Credit_Hours, Dept_name AS Department FROM Course;";
                // Create a SqlDataAdapter to fetch the data
                SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                // Fill the DataTable with the data from the database
                adapter.Fill(dt);
            }
            // Bind the DataTable to the DataGridView
            dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Delete the selected row from the database
           
            {

              string b1 = textBox1.Text;
              string b2 = textBox2.Text;
              string b3 = textBox3.Text;
              string b4 = textBox4.Text;


                //connection string
                string query= "DELETE FROM Course WHERE Name = '" + b1 + "'";
                SqlConnection dbConnection = new SqlConnection(connectionString);
                dbConnection.Open();
                SqlCommand command = new SqlCommand(query, dbConnection);
                command.ExecuteNonQuery();
                MessageBox.Show("Data Deleted Successfully");
                LoadData();
                dbConnection.Close();


            }
                            
                            
                        
                    }
                }
            }
        
    


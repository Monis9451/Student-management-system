﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBS_Project1
{
    public partial class Form5 : Form
    {
        public static Form5 instance;
        public Form5()
        {
            InitializeComponent();
            instance = this;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            using (GraphicsPath path = new GraphicsPath())
            {
                int radius = 20; // Adjust the radius as needed

                // Define a rectangle with rounded corners
                Rectangle rect = new Rectangle(0, 0, panel1.Width - 1, panel1.Height - 1); // Subtract 1 to prevent clipping of border
                path.AddArc(rect.X, rect.Y, radius * 2, radius * 2, 180, 90);
                path.AddArc(rect.X + rect.Width - radius * 2, rect.Y, radius * 2, radius * 2, 270, 90);
                path.AddArc(rect.X + rect.Width - radius * 2, rect.Y + rect.Height - radius * 2, radius * 2, radius * 2, 0, 90);
                path.AddArc(rect.X, rect.Y + rect.Height - radius * 2, radius * 2, radius * 2, 90, 90);
                path.CloseFigure();

                // Set the panel's region to the rounded rectangle path
                panel1.Region = new Region(path);

                // Draw the border
                using (Pen pen = new Pen(Color.SkyBlue, 2)) // Adjust the width as needed
                {
                    e.Graphics.DrawPath(pen, path);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            teacher_info t_info = new teacher_info();
            t_info.Show();
            this.Hide();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            teacher_modify tm = new teacher_modify();
            tm.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //opdn upload attendance form
            UploadAttendance UA = new UploadAttendance();
            UA.Show();
            this.Hide();

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            see_Students s = new see_Students();
            s.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Upload_grade UG = new Upload_grade();
            UG.Show();
            this.Hide();
        }
    }
}

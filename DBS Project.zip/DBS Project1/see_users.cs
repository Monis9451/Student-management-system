﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBS_Project1
{
    public partial class see_users : Form
    {
        public see_users()
        {
            InitializeComponent();
            fills1();
            fills2();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Admin_portal AP = new Admin_portal();
            AP.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void fills1()
        {
            string query = "";
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            query = "SELECT students.s_username AS Username,students.s_f_name AS First_Name,students.s_l_name AS Surname,students.s_age AS Age,students.s_email AS Email,students.s_pass AS Password,students.s_dept AS Department,fee.f_status AS Fee_status, fee.due_date, fee.Sub_date AS Submition_date  FROM students  LEFT JOIN enrollment ON students.s_username=enrollment.st_username  LEFT JOIN fee ON fee.st_username=students.s_username;";
            SqlCommand cmd = new SqlCommand(query, connection);
            DataSet DS = new DataSet();
            SqlDataAdapter DA = new SqlDataAdapter(cmd);
            DA.Fill(DS, "teachers");
            dataGridView1.DataSource = DS.Tables["teachers"];
            connection.Close();
        }
        private void fills2()
        {
            string query = "";
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            query = "SELECT teachers.t_username AS Username,teachers.t_f_name AS First_Name,teachers.t_l_name AS Surname,teachers.t_age AS Age,teachers.t_email AS Email,teachers.t_pass AS Password,teachers.t_dept AS Department FROM teachers;";
            SqlCommand cmd = new SqlCommand(query, connection);
            DataSet DS = new DataSet();
            SqlDataAdapter DA = new SqlDataAdapter(cmd);
            DA.Fill(DS, "teachers");
            dataGridView2.DataSource = DS.Tables["teachers"];
            connection.Close();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

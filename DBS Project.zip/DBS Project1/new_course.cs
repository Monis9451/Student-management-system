﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DBS_Project1
{
    public partial class new_course : Form
    {
        public new_course()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            offer o = new offer();
            o.Show();
            this.Hide();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox4.Text, out _))
            {
                // If not a valid number, clear the TextBox
                textBox4.Text = "";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Address of SQL server and Database
            string connection_string = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";

            // Establish connection
            using (SqlConnection connection = new SqlConnection(connection_string))
            {
                // Open connection
                connection.Open();

                // Create query
                string query = "";
                string CN = textBox1.Text;
                string Desc = textBox2.Text;
                string Credits = textBox3.Text;
                string Dept = textBox4.Text;

                // Insert data into the teacher table
                query = " INSERT INTO Course(Name, Description,Credits, Dept_name) VALUES('" + CN + "','" + Desc + "'," + Credits + ",'" + Dept + "')";

                // Execute query
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.ExecuteNonQuery();
                }
                // Close connection
                connection.Close();
                MessageBox.Show("New course Offered successfully");
            }
            
        }
    }
}

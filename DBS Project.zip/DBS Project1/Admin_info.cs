﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBS_Project1
{
    public partial class Admin_info : Form
    {
        public Admin_info()
        {
            InitializeComponent();
            fill();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Admin_portal admin_Portal = new Admin_portal();
            admin_Portal.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void fill()
        {
            string query = "";
            string connectionString = "Data Source=DESKTOP-OC08KS2;Initial Catalog=DBSPROJECT;Integrated Security=True;Encrypt=False";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();
            query = "SELECT a_f_name AS FirstName, a_l_name AS Surname, a_age AS Age, a_email AS Email, a_pass AS Password, a_username AS Username FROM admins WHERE a_username = '" + admin_info.loggedinadminusername + "'";
            SqlCommand cmd = new SqlCommand(query, connection);
            DataSet DS = new DataSet();
            SqlDataAdapter DA = new SqlDataAdapter(cmd);
            DA.Fill(DS, "admins");
            dataGridView1.DataSource = DS.Tables["admins"];
            connection.Close();
        }
    }
}

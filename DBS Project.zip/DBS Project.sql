CREATE DATABASE DBSPROJECT;

CREATE TABLE Department (
 DepartmentID INT identity (1,1),
 Dept_name VARCHAR (50) PRIMARY KEY
 );
 
CREATE TABLE admins(
 a_username VARCHAR(50) PRIMARY KEY,
 a_f_name VARCHAR(50),
 a_l_name VARCHAR(50),
 a_age INT,
 a_email VARCHAR(50),
 a_pass VARCHAR(50));

CREATE TABLE teachers(
 t_username VARCHAR(50) PRIMARY KEY,
 t_f_name VARCHAR(50),
 t_l_name VARCHAR(50),
 t_age INT,
 t_email VARCHAR(50),
 t_pass VARCHAR(50),
 t_dept VARCHAR(50)
 FOREIGN KEY (t_dept) REFERENCES Department(Dept_name));

 CREATE TABLE students(
 s_username VARCHAR(50) PRIMARY KEY,
 s_f_name VARCHAR(50),
 s_l_name VARCHAR(50),
 s_age INT,
 s_email VARCHAR(50),
 s_pass VARCHAR(50),
 s_dept VARCHAR(50)
 FOREIGN KEY (s_dept) REFERENCES Department(Dept_name));

CREATE TABLE Course (
 CourseID INT primary key identity(1,1),
 Name VARCHAR(50) not null,
 Description varchar(300),
 Credits INT not null CHECK (Credits > 0 AND Credits < 5),
 Dept_name VARCHAR(50) foreign key(Dept_name) references Department(Dept_name)
);


CREATE TABLE enrollment (
enroll_id INT PRIMARY KEY IDENTITY(1,1),
st_username VARCHAR(50) FOREIGN KEY (st_username) REFERENCES students(s_username),
course_id INT FOREIGN KEY (course_id) REFERENCES Course (CourseID),
enroll_date DATE);

CREATE TABLE grade (
st_username VARCHAR(50) FOREIGN KEY (st_username) REFERENCES students(s_username),
course_id INT FOREIGN KEY (course_id) REFERENCES Course (CourseID),
grade VARCHAR (10));

CREATE TABLE fee (
fee_sub_id INT PRIMARY KEY IDENTITY(1,1),
st_username VARCHAR(50) FOREIGN KEY (st_username) REFERENCES students(s_username),
Sub_date DATE,
Amount DECIMAL(10, 2),
f_status BIT,
f_Description TEXT,
due_date DATE);

DROP TABLE attendance;	

CREATE TABLE attendance (
	attendance_id INT PRIMARY KEY IDENTITY (1,1),
	student_name VARCHAR(50) FOREIGN KEY REFERENCES students(s_username) ,
	attendance_date DATE,
	attendance_status VARCHAR(10)
);

 SELECT * FROM Department;
 SELECT * FROM admins;
 SELECT * FROM teachers;
 SELECT * FROM students;
 SELECT * FROM Course;
 SELECT * FROM enrollment;
 SELECT * FROM fee;
 SELECT * FROM grade;
 SELECT * FROM attendance;
 insert into grade(st_username,course_id,grade) values 
  ('aleem12','2024-05-10',5000,0,'Paid','2024-05-20'),
  ('aleem123','2024-05-10',5000,0,'Paid','2024-05-20'),
  ('monis123','2024-05-09',4000,1,'Paid','2024-05-20'),
  ('saba12','2024-05-10',5000,0,'Paid','2024-05-20'),
  ('tayba121','2024-05-11',4000,1,'Paid','2024-05-20');
 INSERT INTO enrollment(st_username,course_id,enroll_date) VALUES ('',12,2004-05-5)
 delete from students where s_username = 'aleem12';
 delete from students where s_age=19;
 INSERT INTO students(s_username,s_f_name,s_l_name,s_age,s_email,s_pass,s_dept) VALUES('aleem123','talha','aleem',18,'aleem@gmail.com', '112233', 'CS');

 INSERT INTO Course(Name, Description,Credits, Dept_name) VALUES('course name','description',3,'CS');
 SELECT Name AS Course_Name,Description,Credits AS Credit_Hours,Dept_name AS Department FROM Course; 


 
 SELECT students.s_username AS Username,students.s_f_name AS First_Name,students.s_l_name AS Surname,students.s_age AS Age,students.s_email AS Email,students.s_pass AS Password,students.s_dept AS Department,fee.f_status AS Fee_status, fee.due_date, fee.Sub_date AS Submition_date  FROM students INNER JOIN enrollment ON students.s_username=enrollment.st_username INNER JOIN fee ON fee.st_username=students.s_username;
 SELECT teachers.t_username AS Username,teachers.t_f_name AS First_Name,teachers.t_l_name AS Surname,teachers.t_age AS Age,teachers.t_email AS Email,teachers.t_pass AS Password,teachers.t_dept AS Department FROM teachers;
 Delete from students where s_username = '';
